import React from 'react';
import MainContent from './MainContent';

export default function Settings() {
  return <MainContent />;
} 